const { spawn } = require('child_process');
var exec = require('child_process').exec;
const gulp = require('gulp');
const nodemon = require('gulp-nodemon');

gulp.task('api', () => nodemon({
  script: './bin/www',
  watch: ['./src']
}));

gulp.task('run-mongo', function (cb) {
  exec('ping localhost', function (err, stdout, stderr) {
    console.log(stdout);
    console.log(stderr);
    cb(err);
  });
})

gulp.task('compass', function (cb) {
  exec('ping localhost', function (err, stdout, stderr) {
    console.log(stdout);
    console.log(stderr);
    cb(err);
  });
})

gulp.task('mongo', (callback) => {
  const dbProcess = spawn('mongod');
  dbProcess.on('data', console.log);
  dbProcess.on('close', (code) => {
    console.log(`Database was stopped with code ${code}`);
    callback();
  });
});

gulp.task('run:dev', ['api']);