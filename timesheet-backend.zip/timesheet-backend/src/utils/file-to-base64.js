var fs = require('fs');
var environment = require('./../constants/environment');
var asyncLoop = require('node-async-loop');

const getBase64 = function (listItems, callback) {
    //filePath = environment.deviceQrCodePath + itemId;
    //console.log(filePath);

    asyncLoop(listItems, function (item, next) {
        let qrFilePath = environment.deviceQrCodePath + item._id + '.png';
        fs.readFile(qrFilePath, { encoding: 'base64' }, (err, data) => {
            if (err) {
                callback(err);
                throw err;
            } else {
                let deviceFilePath = `${environment.dataFilePath+item._id}.${item.photoFileExt}`;
                item.qrCode = 'data:image/png;base64,' + data;
                fs.readFile(deviceFilePath, { encoding: 'base64' }, (err, data) => {
                    if (err) {
                        throw err;
                        //callback(err);
                    } else {
                        item.photos = 'data:image/' + item.photoFileExt + ';base64,' + data;
                    }
                    next();
                });
            }
            // next();
        });
    }, function () {
        console.log('Finished!');
        callback(listItems); //return listItems;
        //res.status(200).send({ items });
    });
}

const createBase64 = function (itemId) {

    var base64String = 'swesh523sfsfgwg';
    base64.decode(base64String, 'text.new.txt', function (err, output) {
        console.log('success');
    });

}

module.exports = { getBase64 };