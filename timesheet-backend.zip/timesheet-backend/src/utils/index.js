module.exports = {
    qrCode: require('./QR-generator'), 
    fileMover: require('./move-file-helper'),
    fileToBase64: require('./file-to-base64')
  };