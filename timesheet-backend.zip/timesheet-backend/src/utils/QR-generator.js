var fs = require('fs');
var qr = require('qr-image');

var environment = require('./../constants/environment');

const generateQR = function (qrText, callback) {    

    if (qrText) {        
        var code = qr.image(qrText.toString(), { type: 'png' });
        var output = fs.createWriteStream(environment.deviceQrCodePath + qrText + '.png')
        code.pipe(output);
        callback(output);
    } else {
        callback('error');
    }

}

module.exports = { generateQR };