var fs = require('fs');
var environment = require('./../constants/environment');

const move = function (oldPath, newPath, callback) {

    let fileExt = `${newPath}.${oldPath.split('.')[1]}`;
    var destination = `${environment.dataFilePath}${fileExt}`;
    var source = `${environment.tempFileUploadPath}${oldPath}`;

    fs.rename(source, destination, function (err) {
        if (err) {
            if (err.code === 'EXDEV') {
                copy();
            } else {
                callback(err);
            }
            return;
        }
        callback();
    });

    function copy() {
        var readStream = fs.createReadStream(source);
        var writeStream = fs.createWriteStream(designation);

        readStream.on('error', callback);
        writeStream.on('error', callback);

        readStream.on('close', function () {
            fs.unlink(source, callback);
        });

        readStream.pipe(writeStream);
    }
}

module.exports = { move };