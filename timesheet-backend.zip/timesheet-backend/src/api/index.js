const express = require('express');
const { errorHandler } = require('../middleware');


const {mainCategoryModel, mainCategoryCtrl} = require('./main-category');
const {subCategoryModel, subCategoryCtrl} = require('./sub-category');

const routersInit = config => {
  const router = express();

  // register api points
  

  router.use('/main-category', mainCategoryCtrl(mainCategoryModel, { config }));
  router.use('/sub-category', subCategoryCtrl(subCategoryModel, { config }));
  
   // catch api all errors
  router.use(errorHandler);
  return router;
};

module.exports = routersInit;