
const subCategoryCtrl = require('./controllers');

const subCategoryModel = require('./models/sub-category.schema');





module.exports = { subCategoryModel, subCategoryCtrl };