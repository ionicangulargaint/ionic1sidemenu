const { NotAcceptable } = require('rest-api-errors');
const { sendOne } = require('../../../middleware');
const mongoose = require('mongoose');
const _ = require('lodash');

const create = ({ subCategoryModel }, { config }) => async (req, res, next) => {
  try {    
    if (!req.body) {
      throw new NotAcceptable(405, 'Should by title');
    }
    const model = new subCategoryModel();
    _.extend(model, req.body);
    await model.save();
    res.status(200).send({ model });    
     
  } catch (error) {
    next(error);
  }
};

module.exports = { create };


