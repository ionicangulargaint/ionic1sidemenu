const _ = require('lodash');

const update = ({ subCategoryModel }, { config }) => async (req, res, next) => {
  const { _id } = req.params;
  try {
    const model = await subCategoryModel.findOne({ _id });
    _.extend(model, req.body);
    await model.save();
    res.status(200).send({ model });
  } catch (error) {
    next(error);
  }
};

module.exports= { update };
