const _ = require('lodash');
const mongoose = require('mongoose');

const list = ({ mainCategoryModel }, { config }) => async (req, res, next) => {
  let { limit, page, search } = req.query;

  // page = parseInt(req.query.page) || 0; //for next page pass 1 here
  // limit = parseInt(req.query.limit) || 3;

  page = page ? parseInt(page-1, 10) : 0;
  limit = limit ? parseInt(limit, 10) : 100;

  try {
    const query = {};
    if (search) {
      _.extend(query, { title: new RegExp(`${search}`, 'i') })
    }
    await mainCategoryModel.find(query)
      .skip((page) * limit)
      .sort({ update_at: -1 })
      .limit(limit)      
      .exec((err, items) => {
        if(items){
          if (items.length != 0) {
            mainCategoryModel.count(query).exec((count_error, count) => {
              if (err) {
                return res.json(count_error);
              }
              res.status(200).send({ 
                items: items,
                total: count,
                page: page,
                pageSize: items.length,
              });            
            });                      
          } else {
            res.status(200).send({ list: [] });
          }
        } else{
          res.status(200).send({ list: [] });
        }        
      })
  } catch (error) {
    next(error);
  }
};

module.exports = { list };
