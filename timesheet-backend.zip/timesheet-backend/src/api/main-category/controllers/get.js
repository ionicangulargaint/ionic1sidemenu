const get = ({ mainCategoryModel }, { config }) => async (req, res, next) => {  
  const { _id } = req.params;
  try {
    const model = await mainCategoryModel.findOne({ _id });
    res.status(200).send({ model });
    
  } catch (error) {
    next(error);
  }

};

module.exports= { get };
