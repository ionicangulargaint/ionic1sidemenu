const { NotAcceptable } = require('rest-api-errors');
const { sendOne } = require('../../../middleware');
const mongoose = require('mongoose');
const _ = require('lodash');

const create = ({ mainCategoryModel }, { config }) => async (req, res, next) => {
  try {    
    if (!req.body) {
      throw new NotAcceptable(405, 'Should by title');
    }
    const mainCategoryRef = new mainCategoryModel();
    _.extend(mainCategoryRef, req.body);
    await mainCategoryRef.save();
    res.status(200).send({ mainCategoryRef });    
     
  } catch (error) {
    next(error);
  }
};

module.exports = { create };


