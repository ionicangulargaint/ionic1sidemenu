
const mainCategoryCtrl = require('./controllers');

const mainCategoryModel = require('./models/main-category.schema');





module.exports = { mainCategoryModel, mainCategoryCtrl };