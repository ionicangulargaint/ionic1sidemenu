const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const ObjectId = Schema.Types.ObjectId;

const schema = new Schema({  
  name:{
    type: String,
    required: [true]
  },
  description: {
    type: String
  }

}, {collection: 'main-category', timestamps:true});

const mainCategoryModel = mongoose.model('main-category', schema);
module.exports = { mainCategoryModel };