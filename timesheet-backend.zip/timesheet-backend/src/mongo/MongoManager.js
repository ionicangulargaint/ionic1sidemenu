const mongoose = require('mongoose');
class MongoManager {
  constructor(config) {
    this._config = config;
  }
  getMongoUrl() {
    return this._config.MONGODB_URI;
  }
  connect() {
    mongoose.connect(this.getMongoUrl(), {}).then(
      (success) => {
        console.log('connection success' + success)
        // success.connection.db.listCollections({name: 'masterDataTypes'})
        // .next(function(err, collectionInfo) {
        //   if(collectionInfo == null) {
            
        //       //creating master data items table
        //       // const masterDataType = mongoose.model('masterDataTypes');
        //       // masterDataType.create(
        //       //   {
        //       //     "name": "Project Scope",
        //       //     "createdAt": Date.now(),
        //       //     "updatedAt": Date.now()
        //       //   },
        //       //   {
        //       //     "name": "Project Status",
        //       //     "createdAt": Date.now(),
        //       //     "updatedAt": Date.now()
        //       //   },
        //       //   {
        //       //     "name": "Type of construction",
        //       //     "createdAt": Date.now(),
        //       //     "updatedAt": Date.now()
        //       //   },
        //       //   {
        //       //     "name": "Work order no status",
        //       //     "createdAt": Date.now(),
        //       //     "updatedAt": Date.now()
        //       //   },
        //         // function (err, success) {
        //         //   if (err) console.log(err);
        //         // })
        //   }
        // });
       },
      (err) => { 
        console.log('Unable to connect to DB')
        err
       }
    );
  }

}

module.exports = { MongoManager };