const { MongoManager } = require('./MongoManager');

module.exports = { MongoManager };