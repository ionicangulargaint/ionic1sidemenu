module.exports = Object.freeze({
  tempFileUploadPath: 'files/temp/',
  dataFilePath: 'files/device-photos/',
  deviceQrCodePath: 'files/device-qr-codes/'
});